
(function(){
  const NAMESPACE = 'jeel-site-final';
  const CATS = [];
  for(let i=1;i<=10;i++){ CATS.push({id:i, file:'skills/skills-category-'+i+'.json', name_ar:'فئة '+i}); }
  function $id(i){return document.getElementById(i);}
  async function loadJSON(p){ try{ const r=await fetch(p,{cache:'no-store'}); if(!r.ok) return null; return await r.json(); }catch(e){return null;} }
  let lang = localStorage.getItem('jeel_lang') || 'ar';
  let currentType = 'soft';
  let currentSkills = [];
  document.addEventListener('DOMContentLoaded', async ()=>{
    const langBtn = $id('langBtn'), btnSoft=$id('btnSoft'), btnHard=$id('btnHard'), catsEl=$id('cats'), grid=$id('grid'), search=$id('search'), vc=$id('vc');
    const modal=$id('modal'), closeModal=$id('closeModal'), modalBody=$id('modalBody');
    function applyLang(){ if(lang==='ar'){ document.documentElement.lang='ar'; document.documentElement.dir='rtl'; langBtn.textContent='العربية'; } else{ document.documentElement.lang='en'; document.documentElement.dir='ltr'; langBtn.textContent='English'; } renderGrid(); }
    langBtn && langBtn.addEventListener('click', ()=>{ lang = (lang==='ar')? 'en':'ar'; localStorage.setItem('jeel_lang', lang); applyLang(); });
    // build categories with labels from skills files
    for(const c of CATS){ const b=document.createElement('button'); b.className='cat-btn'; b.innerText = 'فئة '+c.id; b.addEventListener('click', ()=> loadCategory(c)); catsEl.appendChild(b); }
    btnSoft.addEventListener('click', ()=>{ currentType='soft'; btnSoft.classList.add('active'); btnHard.classList.remove('active'); loadCategory(CATS[0]); });
    btnHard.addEventListener('click', ()=>{ currentType='hard'; btnHard.classList.add('active'); btnSoft.classList.remove('active'); loadCategory(CATS[0]); });
    search.addEventListener('keydown', (e)=>{ if(e.key==='Enter'){ const q=(search.value||'').trim(); if(q==='احصاء' || q.toLowerCase()==='statistics'){ try{ sessionStorage.setItem('allowStats','1'); }catch(e){} window.location='stats.html'; return; } renderGrid(q.toLowerCase()); } });
    closeModal && closeModal.addEventListener('click', ()=> modal && modal.classList.add('hidden'));
    const splash = $id('splash'); setTimeout(()=>{ if(splash) splash.classList.add('fade-out'); setTimeout(()=>splash&&splash.remove(),800); },3000); splash && splash.addEventListener('click', ()=>{ splash.classList.add('fade-out'); setTimeout(()=>splash&&splash.remove(),400); });
    await loadCategory(CATS[0]);
    applyLang();
    updateCounter(); setInterval(updateCounter, 60*1000);
    async function loadCategory(cat){ const data = await loadJSON(cat.file); if(!data||!Array.isArray(data.skills)){ currentSkills=[]; renderGrid(); return;} currentSkills = data.skills.filter(s=>s.type===currentType); renderGrid(); }
    function renderGrid(filter=''){ grid.innerHTML=''; const q = filter || (search && (search.value||'').trim().toLowerCase()) || ''; const list = currentSkills.filter(s=>{ if(!q) return true; const name = ((lang==='ar')? s.name_ar : s.name_en).toLowerCase(); const desc = ((lang==='ar')? s.description_ar : s.description_en).toLowerCase(); return name.includes(q) || desc.includes(q); }); if(list.length===0){ grid.innerHTML = '<div style="padding:18px;opacity:.7">'+(lang==='ar'? 'لا توجد مهارات للعرض' : 'No skills to show')+'</div>'; return; } list.forEach(s=>{ const card=document.createElement('div'); card.className='card'; const name = (lang==='ar'? s.name_ar : s.name_en); const icon = s.icon || (s.type==='hard'? '🛠️':'🤝'); card.innerHTML = '<div class=\"icon\">'+icon+'</div><div class=\"title\">'+name+'</div>'; card.addEventListener('click', ()=> openModal(s)); grid.appendChild(card); }); }
    function openModal(s){ modalBody.innerHTML = '<h2>'+ (s.icon||'') + ' ' + (lang==='ar'? s.name_ar : s.name_en) + '</h2><p style=\"white-space:pre-line\">'+ (lang==='ar'? s.description_ar: s.description_en) + '</p><h3>' + (lang==='ar'? 'تطبيقات عملية' : 'Practical Apps') + '</h3><ol>' + ((lang==='ar'? s.applications_ar: s.applications_en)||[]).map(a=>'<li>'+a+'</li>').join('') + '</ol>'; modal.classList.remove('hidden'); }
    async function updateCounter(){ try{ await fetch('https://api.countapi.xyz/hit/'+encodeURIComponent(NAMESPACE)+'/visitors'); const today = new Date().toISOString().slice(0,10); await fetch('https://api.countapi.xyz/hit/'+encodeURIComponent(NAMESPACE)+'/'+encodeURIComponent('vis-'+today)); const r = await fetch('https://api.countapi.xyz/get/'+encodeURIComponent(NAMESPACE)+'/visitors'); if(r.ok){ const j = await r.json(); const vc = $id('vc'); if(vc) vc.textContent = j.value; } }catch(e){ console.warn('CountAPI', e); } }
  });
})();