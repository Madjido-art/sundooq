
(function(){
const c=document.getElementById('bg'); if(!c) return; const ctx=c.getContext('2d'); let w,h,parts=[];
function r(){w=c.width=innerWidth; h=c.height=innerHeight;} window.addEventListener('resize',r); r();
function rand(a,b){return Math.random()*(b-a)+a;} for(let i=0;i<140;i++){parts.push({x:rand(0,w),y:rand(0,h),r:rand(0.6,3.5),vx:rand(-0.4,0.4),vy:rand(-0.2,0.2),a:rand(0.02,0.9)})}
let t=0; function loop(){ctx.clearRect(0,0,w,h); t+=0.01; for(const p of parts){p.x+=p.vx + Math.sin(t+p.r)*0.1; p.y+=p.vy + Math.cos(t+p.r)*0.1; if(p.x<0)p.x=w; if(p.x>w)p.x=0; if(p.y<0)p.y=h; if(p.y>h)p.y=0; const g=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,p.r*10); g.addColorStop(0,'rgba(124,58,237,'+p.a+')'); g.addColorStop(0.6,'rgba(91,47,166,'+(p.a*0.6)+')'); g.addColorStop(1,'rgba(43,11,106,0)'); ctx.fillStyle=g; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fill(); } requestAnimationFrame(loop);} loop();
})();
