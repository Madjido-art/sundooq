# Goodness Box (صندوق الخير)

## 🚀 النشر على GitHub Pages

1. أنشئ مستودعاً جديداً في حسابك على [GitHub](https://github.com).
   - الاسم المقترح: `goodness-box`
   - اجعله **عاماً (Public)**.
2. ارفع هذا المجلد (بعد فك ضغطه) إلى المستودع (الملفات: `index.html` و`README.md`).
3. بعد رفع الملفات، اذهب إلى:
   - Settings → Pages
   - من قسم "Build and deployment" اختر الفرع `main` والمسار `/ (root)`.
4. اضغط **Save**.
5. بعد دقيقة تقريباً ستحصل على رابط مثل:
   👉 https://USERNAME.github.io/goodness-box/

يمكنك تعديل `index.html` كما تشاء.
